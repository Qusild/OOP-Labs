using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameScaler : MonoBehaviour
{
    private const int BasicWidth = 200;
    private const int BasicR1 = 150;
    private const int BasicR2 = 100;
    private const float BasicWallScale = 10f;
    private const float BasicR2Scale = 1f;
    private const float BasicR1Scale = 1.5f;
    private const float BasicCameraSize = 15.58038f;
    private const float BasicCarY = 16.67f;
    private const float BasicCarScale = 1f;
    private GameObject mainTrack;
    private GameObject innerWalls;
    private GameObject outerWalls;
    private GameObject Camera;
    private GameObject Car;
    void Awake()
    {
        mainTrack = GameObject.Find("Walls");
        innerWalls = GameObject.Find("InnerWalls");
        outerWalls = GameObject.Find("OuterWalls");
        Camera = GameObject.Find("Main Camera");
        Car = GameObject.Find("Car");
        //newGameScaleParameter("200,150,100");
    }
    public void newGameScaleParameter(string input)
    {
        string[] values = input.Split(',');   
        int tmp, i = 0;
        float[] scale = new float[3];
        float carScale;
        foreach (string value in values)
        {
            if(System.Int32.TryParse(value, out tmp))
            {
                if (tmp <= 0)
                    return;
                scale[i] = tmp;
                i++;
            }
            else return;
        }
        if (scale[1]<=scale[2]) return;
        carScale = BasicCarScale * ((scale[1]-scale[2])/3)/BasicCarY;
        scale[0] =  (scale[0] / BasicWidth + scale[2] / BasicR2)/2;
        scale[1] =  scale[1] / BasicR1;
        scale[2] =  scale[2] / BasicR2;
        mainTrack.transform.localScale = new Vector3(BasicWallScale * scale[0], BasicWallScale, 1);
        innerWalls.transform.localScale = new Vector3(1,BasicR2Scale * scale[2],1);
        outerWalls.transform.localScale = new Vector3(1.25f,BasicR1Scale * scale[1],1);
        Camera.GetComponent<Camera>().orthographicSize = BasicCameraSize * System.Math.Max(scale[0],scale[1]);
        Car.GetComponent<CarController>().setRotationAngle(-90);
        Car.transform.localScale = new Vector3(carScale, carScale*1.5f ,1);
        Car.transform.position = new Vector3(0,(13*scale[2]+13*scale[1])/2,0);
        //Car.transform.rotation = new Quaternion(0,0,0,Car.transform.rotation.z-Car.transform.rotation.z);
    }
}
