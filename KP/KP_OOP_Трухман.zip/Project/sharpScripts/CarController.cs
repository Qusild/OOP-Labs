using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarController : MonoBehaviour
{
    [Header("Car Mechanic settings")]
    public float accelerationFactor = 30.0f;
    public float turnFactor = 3.5f;
    public float driftFactor = 0.5f;

    public float maxSpeed = 20.0f;

    private float accelerationInput=0;
    private float steeringInput=0;
    private float rotationAngle=-90;

    private float VelcityVsUp = 0.0f;
    Rigidbody2D carBody2D;
    void Awake()
    {
        carBody2D = GetComponent<Rigidbody2D>();
    }
    public void setRotationAngle(float angle)
    {
        rotationAngle = angle;
        carBody2D.velocity = Vector3.zero;
        carBody2D.angularVelocity = 0;
    }
    void removeSideForces()
    {
        Vector2 forwardVelocity = transform.up * Vector2.Dot(carBody2D.velocity, transform.up);
        Vector2 sideVelocity = transform.right * Vector2.Dot(carBody2D.velocity, transform.right);

        carBody2D.velocity = forwardVelocity + sideVelocity*driftFactor;
    }

    // Frame-rate independent for physics calculations
    void FixedUpdate()
    {
        ApplyControlForce();

        removeSideForces(); // Apply drifting factor to car

        ApplySteering();
    }
    public void ChangeMaxSpeed(string inputValue)
    {
        float tmp;
        System.Single.TryParse(inputValue, out tmp);
        if (tmp>0)
            maxSpeed = tmp;
    }
    void ApplyControlForce()
    {
        VelcityVsUp = Vector2.Dot(transform.up,carBody2D.velocity);

        if ((VelcityVsUp > maxSpeed)&&(accelerationInput > 0))
            return;

        if ((VelcityVsUp < -maxSpeed*0.5)&&(accelerationInput < 0))
            return;
        
        if ((carBody2D.velocity.sqrMagnitude > maxSpeed*maxSpeed)&&(accelerationInput > 0))
            return;

        if (accelerationInput == 0)
            carBody2D.drag = Mathf.Lerp(carBody2D.drag,3.0f,Time.fixedDeltaTime * 3);
        else carBody2D.drag = 0;
        Vector2 ControlForceVector = transform.up * accelerationInput * accelerationFactor;

        carBody2D.AddForce(ControlForceVector, ForceMode2D.Force); 
    }

    void ApplySteering()
    {
        float minimalSpeedBeforeTurning = (carBody2D.velocity.magnitude/10);

        minimalSpeedBeforeTurning = Mathf.Clamp01(minimalSpeedBeforeTurning);

        rotationAngle -= steeringInput * turnFactor * minimalSpeedBeforeTurning;

        carBody2D.MoveRotation(rotationAngle);
    }

    public void SetInputVector(Vector2 inputVector)
    {
        steeringInput = inputVector.x;
        accelerationInput = inputVector.y;
    }
}
