using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputHandler : MonoBehaviour
{
    CarController _controller;
    void Awake()
    {
        _controller = GetComponent<CarController>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Vector2 inputVector = Vector2.zero;
        if(Input.GetKeyDown("escape"))
            Application.Quit();

        inputVector.x = Input.GetAxis("Horizontal");
        inputVector.y = Input.GetAxis("Vertical");

        _controller.SetInputVector(inputVector);
    }
}
