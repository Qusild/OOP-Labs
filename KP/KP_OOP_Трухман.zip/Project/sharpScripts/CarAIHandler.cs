using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class CarAIHandler : MonoBehaviour
{
    [Header("Ray Cast Range")]
    public float rayRange = 15.0f;
    public bool isAutoPiloted = true;
    
    CarController topDownCarController;
    Vector2 inputVector = Vector2.zero;
    PolygonCollider2D polygonCollider2D;
    void Awake()
    {
        topDownCarController = GetComponent<CarController>();
        polygonCollider2D = GetComponentInChildren<PolygonCollider2D>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        rayRange = 10.0f * GameObject.Find("Car").transform.localScale.x;
        if (isAutoPiloted)
        {
            inputVector.x = 0.0f;
            inputVector.y = 1.00f;
            AvoidWalls(ref inputVector);
            topDownCarController.SetInputVector(inputVector);
        }
    }

    bool IsWallInFrontOfCar(ref Vector2 inputVector)
    {
        polygonCollider2D.enabled = false;
        Vector3 forwardVector = transform.up * 0.5f;
        int angle = 70;
        Vector3 left = new Vector3(forwardVector.x*(float)Math.Cos(angle)-forwardVector.y*(float)Math.Sin(angle),
                                   forwardVector.x*(float)Math.Sin(angle)+forwardVector.y*(float)Math.Cos(angle),
                                   forwardVector.z);
        Vector3 right = new Vector3(forwardVector.x*(float)Math.Cos(-angle)-forwardVector.y*(float)Math.Sin(-angle),
                                   forwardVector.x*(float)Math.Sin(-angle)+forwardVector.y*(float)Math.Cos(-angle),
                                   forwardVector.z);
        RaycastHit2D rayCastHit2D =  Physics2D.Raycast(transform.position + forwardVector, transform.up,rayRange);
        RaycastHit2D rayCastHit2DLeft = Physics2D.Raycast(transform.position, transform.up+left,rayRange*0.5f);
        RaycastHit2D rayCastHit2DRight = Physics2D.Raycast(transform.position, transform.up+ right,rayRange*0.4f);
        polygonCollider2D.enabled = true;
        if (rayCastHit2DRight.collider != null)
        {
            Debug.DrawRay(transform.position, transform.up * rayRange, Color.green);
            Debug.DrawRay(transform.position, left * rayRange*0.5f, Color.green);
            Debug.DrawRay(transform.position, right * rayRange*0.4f, Color.red);
            inputVector.x = -1.0f;
            inputVector.y = 0.3f;
            return true;
        }
        if (rayCastHit2D.collider != null)
        {
            Debug.DrawRay(transform.position, transform.up * rayRange, Color.red);
            Debug.DrawRay(transform.position, left * rayRange*0.5f, Color.green);
            Debug.DrawRay(transform.position, right * rayRange*0.4f, Color.green);
            inputVector.x = 1.0f;
            inputVector.y = 0.3f;
            return true;
        }
        if (rayCastHit2DLeft.collider != null)
        {
            Debug.DrawRay(transform.position, transform.up * rayRange, Color.green);
            Debug.DrawRay(transform.position, left * rayRange*0.5f, Color.red);
            Debug.DrawRay(transform.position, right * rayRange*0.4f, Color.green);
            inputVector.x = 1.0f;
            inputVector.y = 0.3f;
            return true;
        }
        Debug.DrawRay(transform.position, transform.up * rayRange, Color.green);
        Debug.DrawRay(transform.position, left * rayRange*0.5f, Color.green);
        Debug.DrawRay(transform.position, right * rayRange*0.4f, Color.green);
        return false;
    }

    void AvoidWalls(ref Vector2 inputVector)
    {
        if (!IsWallInFrontOfCar(ref inputVector))
            inputVector.x = 0.0f;
    }

    public void AutoPilotToggle(bool toggle)
    {
        inputVector.y = 0f;
        isAutoPiloted = toggle;
    }
}
